import Hero from "../components/Hero";
import Services from "../components/Services";
import Refurbished from "../components/Refurbished";

const Home = () => {
  return (
    <>
      <Hero />
      <Services />
      <Refurbished />
    </>
  );
};

export default Home;
