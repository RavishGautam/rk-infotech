const Contact = () => {
  return (
    <section className="pt-28 pb-20">
      <h1 className="text-3xl sm:text-4xl font-bold text-center mb-12">
        Contact Us
      </h1>

      <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-10">

        {/* Contact Info */}
        <div>
          <p className="mb-4">📍 Mumbai | Navi Mumbai | Thane</p>
          <p className="mb-4">📞 +91 99999 99999</p>
          <p className="mb-4">📧 rkinfotech@email.com</p>

          <iframe
            className="w-full h-64 rounded-lg"
            src="https://www.google.com/maps?q=Mumbai&output=embed"
            loading="lazy"
          ></iframe>
        </div>

        {/* Contact Form */}
        <form className="bg-white p-8 rounded-xl shadow-md">
          <input
            type="text"
            placeholder="Your Name"
            className="w-full border p-3 mb-4 rounded-md"
          />
          <input
            type="email"
            placeholder="Your Email"
            className="w-full border p-3 mb-4 rounded-md"
          />
          <textarea
            placeholder="Your Message"
            className="w-full border p-3 mb-4 rounded-md"
            rows="4"
          ></textarea>
          <button className="bg-primary text-white px-6 py-3 rounded-md">
            Send Message
          </button>
        </form>
      </div>
    </section>
  );
};

export default Contact;
