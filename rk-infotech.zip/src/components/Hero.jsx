const Hero = () => {
  return (
    <section className="pt-28 pb-16 bg-light">
      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">

        {/* Text */}
        <div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            RK Infotech <br />
            Computer & Laptop Sales and Services
          </h1>

          <p className="text-gray-600 mb-8">
            Branded & Assembled Desktops | New & Refurbished Laptops <br />
            Serving Mumbai, Navi Mumbai & Thane
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="tel:+919999999999"
              className="bg-primary text-white px-6 py-3 rounded-md text-center"
            >
              Call Now
            </a>
            <a
              href="https://wa.me/919999999999"
              className="bg-accent text-white px-6 py-3 rounded-md text-center"
            >
              WhatsApp Us
            </a>
          </div>
        </div>

        {/* Image */}
        <img
          src="https://via.placeholder.com/450"
          alt="Computer"
          className="w-full max-w-md mx-auto"
        />
      </div>
    </section>
  );
};

export default Hero;
