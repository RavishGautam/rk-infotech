import { FaDesktop, FaLaptop, FaTools, FaNetworkWired } from "react-icons/fa";

const Services = () => {
  const services = [
    { icon: <FaDesktop />, title: "Desktop Sales & Repair" },
    { icon: <FaLaptop />, title: "Laptop Sales & Repair" },
    { icon: <FaTools />, title: "Software Installation" },
    { icon: <FaNetworkWired />, title: "Network & AMC Services" },
  ];

  return (
    <section className="py-20">
      <h2 className="text-3xl sm:text-4xl font-semibold text-center mb-12">
        Our Services
      </h2>

      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {services.map((service, index) => (
          <div
            key={index}
            className="bg-white p-8 rounded-xl shadow-md text-center hover:shadow-lg transition"
          >
            <div className="text-primary text-4xl mb-4">
              {service.icon}
            </div>
            <h3 className="font-medium text-lg">
              {service.title}
            </h3>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Services;
