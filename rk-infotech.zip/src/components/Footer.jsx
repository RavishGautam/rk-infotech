const Footer = () => {
  return (
    <footer className="bg-primary text-white py-6 text-center px-4">
      © {new Date().getFullYear()} RK Infotech. All Rights Reserved.
    </footer>
  );
};

export default Footer;
