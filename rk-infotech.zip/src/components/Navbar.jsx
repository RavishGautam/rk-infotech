import { useState } from "react";
import { FiMenu, FiX } from "react-icons/fi";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [open, setOpen] = useState(false);

  return (
    <nav className="bg-white shadow-md fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-20 flex items-center justify-between">

        {/* Logo */}
        <div className="text-2xl font-semibold text-primary">
          RK Infotech
        </div>

        {/* Desktop Menu */}
        <ul className="hidden md:flex gap-6 text-gray-700">
         <Link to="/">Home</Link>
<Link to="/products">Products</Link>
<Link to="/contact">Contact</Link>
        </ul>

        {/* CTA */}
        <a
          href="https://wa.me/919999999999"
          className="hidden md:block bg-accent text-white px-4 py-2 rounded-md"
        >
          WhatsApp
        </a>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-2xl"
          onClick={() => setOpen(!open)}
        >
          {open ? <FiX /> : <FiMenu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {open && (
        <div className="md:hidden bg-white shadow-lg">
          <ul className="flex flex-col gap-4 p-6 text-gray-700">
            import { Link } from "react-router-dom";

<Link to="/">Home</Link>
<Link to="/products">Products</Link>
<Link to="/contact">Contact</Link>

            <a
              href="https://wa.me/919999999999"
              className="bg-accent text-white text-center py-2 rounded-md"
            >
              WhatsApp Us
            </a>
          </ul>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
